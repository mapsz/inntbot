<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Http;


// cq90405_inntbot
// TVW2ukEz
 
class Telegram extends Model
{

  public static function getToken(){
    return "2061389685:AAGcqdTFBIqTPXIzNNpG2GSWYETIp-mI78Q";
  }
  public static function getUrl(){
    return "https://api.telegram.org/bot" . self::getToken() . "/";
  }

  public static function send($id, $text ,$buttons = []){

    $reply_markup = json_encode([
      "inline_keyboard" => [[
        [
          "text" => 'Монитор',
          "callback_data" => 'https://www.google.com'
        ],
      ]]
    ]);

    $send = self::getUrl() . 'sendMessage';
    $r = Http::post($send,
      [
        "chat_id" => $id,
        "text" => $text,
        "reply_markup" => $reply_markup,
      ]
    );

    dump((string) $r->getBody());
      
    if($r->getStatusCode() == 200) return true;

    return false;

  }
}
